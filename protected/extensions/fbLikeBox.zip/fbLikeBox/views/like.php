
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&appId=161923053887892&version=v2.0";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>


<div class="fb-like-box" data-href="<?=$rendered['url'];?>" data-width="<?=$rendered['width']?>" data-height="<?=$rendered['height'];?>" data-colorscheme="<?=$rendered['layout'];?>" data-show-faces="<?=$rendered['show_faces'];?>" data-header="<?=$rendered['header'];?>" data-stream="<?=$rendered['show_post'];?>" data-show-border="<?=$rendered['show_border'];?>"></div>
