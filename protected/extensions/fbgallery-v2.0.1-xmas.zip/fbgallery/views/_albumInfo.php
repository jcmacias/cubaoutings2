<div class="albumInfo">
	<?php if($showTitle):?>
		<div class="nameAlbum"><h2><?php echo $infoAlbum['name'];?></h2></div>
	<?php endif;?>
	<?php if($showDescription):?>
		<div class="descriptionAlbum"><h3><?php echo $infoAlbum['description'];?></h3></div>
	<?php endif;?>
</div>