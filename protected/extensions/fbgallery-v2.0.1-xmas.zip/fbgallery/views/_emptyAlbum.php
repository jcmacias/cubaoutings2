<div class="emptyGallery">
	<?php 
		if(isset($empty))
			echo $empty;
		else
			echo $create;
	?>
</div>