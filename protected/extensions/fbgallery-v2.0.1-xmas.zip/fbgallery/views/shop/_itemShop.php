<div class="gTh">
	<div class="imageItem">
		<a class="gImg ttp" rel="<?php echo $item['rel'];?>" title="<?php echo $item['title'];?>" href="<?php echo $item['urlImg'];?>">
			<img src="<?php echo $item['imgSrc'];?>" alt="<?php echo $item['title'];?>" />
		</a>
	</div>
</div>
